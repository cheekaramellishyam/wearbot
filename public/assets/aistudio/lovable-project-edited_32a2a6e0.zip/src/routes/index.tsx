import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { UploadBox } from "@/components/UploadBox";
import { PinterestLogo } from "@/components/PinterestLogo";
import {
  analyseClothing,
  generateOutfits,
  type ClothingAnalysis,
  type OutfitRecommendation,
} from "@/lib/outfit.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WEARBOT — Outfit Recommendations" },
      { name: "description", content: "Match your uploaded tops and bottoms with WEARBOT’s outfit recommendations." },
      { property: "og:title", content: "WEARBOT — Outfit Recommendations" },
      { property: "og:description", content: "Match your uploaded tops and bottoms with WEARBOT’s outfit recommendations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error(`Couldn't read ${file.name}`));
    reader.readAsDataURL(file);
  });
}

function Index() {
  const [shirt, setShirt] = useState<File[]>([]);
  const [pants, setPants] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [recs, setRecs] = useState<OutfitRecommendation[] | null>(null);
  const [previews, setPreviews] = useState<{ tops: string[]; bottoms: string[] }>({ tops: [], bottoms: [] });
  const [shown, setShown] = useState<Record<number, boolean>>({});
  const results = useRef<HTMLElement>(null);
  const cache = useRef(new Map<string, ClothingAnalysis>());
  const runAnalyse = useServerFn(analyseClothing);
  const runGenerate = useServerFn(generateOutfits);
  const ready = shirt.length > 0 && pants.length > 0 && !loading;

  useEffect(() => {
    if (recs) results.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [recs]);

  const onGenerate = async () => {
    setLoading(true);
    setRecs(null);
    setShown({});
    try {
      const [tops, bottoms] = await Promise.all([
        Promise.all(shirt.map(fileToDataUrl)),
        Promise.all(pants.map(fileToDataUrl)),
      ]);
      // Only send photos that haven't been analysed before.
      const fresh = [...new Set([...tops, ...bottoms].filter((u) => !cache.current.has(u)))];
      if (fresh.length) {
        const { items } = await runAnalyse({ data: { images: fresh } });
        fresh.forEach((u, i) => cache.current.set(u, items[i]!));
      }
      const { recommendations } = await runGenerate({
        data: {
          tops: tops.map((u) => cache.current.get(u)!),
          bottoms: bottoms.map((u) => cache.current.get(u)!),
        },
      });
      setPreviews({ tops, bottoms });
      setRecs(recommendations);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong — please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-auto flex min-h-screen max-w-4xl flex-col items-center px-4 py-10 sm:px-6 md:py-16">
      <section className="flex w-full flex-col items-center gap-12 md:flex-row md:items-stretch md:justify-center md:gap-0">
        <div className="flex flex-1 justify-center md:pr-12">
          <UploadBox label="Tops" files={shirt} onChange={(f) => { setShirt(f); setRecs(null); }} />
        </div>
        <div className="hidden w-px bg-line md:block" aria-hidden />
        <div className="flex flex-1 justify-center md:pl-12">
          <UploadBox label="Bottoms" files={pants} onChange={(f) => { setPants(f); setRecs(null); }} />
        </div>
      </section>
      <div className="mt-12 hidden h-px w-full bg-line md:block" aria-hidden />

      <button
        type="button"
        disabled={!ready}
        onClick={onGenerate}
        className="mt-12 flex w-full items-center justify-center gap-2 self-stretch rounded-md bg-pinterest px-8 py-3 text-center text-base font-medium text-primary-foreground transition-opacity hover:opacity-80 disabled:cursor-not-allowed disabled:hover:opacity-100"
      >
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        {loading ? "Analysing your clothes…" : "Generate"}
      </button>

      {recs && (
        <section ref={results} className="mt-16 w-full scroll-mt-6">
          <h2 className="mb-6 flex items-center gap-2 text-xl font-medium">
            Outfit recommendations
            <span className="flex items-center gap-1 text-sm font-normal text-muted-foreground">
              · inspired by <PinterestLogo className="h-4 w-4 text-pinterest" /> Pinterest
            </span>
          </h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
            {recs.map((rec, i) => (
              <div key={i} className="flex flex-col gap-3">
                <div className="flex aspect-[3/4] gap-1 border border-line p-1">
                  <img
                    src={previews.tops[rec.top - 1]}
                    alt={`Top ${rec.top}`}
                    className="h-full w-1/2 object-cover"
                  />
                  <img
                    src={previews.bottoms[rec.bottom - 1]}
                    alt={`Bottom ${rec.bottom}`}
                    className="h-full w-1/2 object-cover"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-semibold">{rec.style} · {rec.score}/10</p>
                  <p className="text-xs text-muted-foreground">Colours: {rec.colors}</p>
                  <p className="text-sm text-muted-foreground">{rec.reason}</p>
                  <p className="text-xs text-muted-foreground">Occasion: {rec.occasion}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShown((s) => ({ ...s, [i]: !s[i] }))}
                  className="flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground transition-opacity hover:opacity-80"
                >
                  <PinterestLogo className="h-4 w-4 text-pinterest" />
                  {shown[i] ? "Hide pinterest image" : "Show pinterest image"}
                </button>
                {shown[i] && (
                  <div className="flex aspect-[3/4] items-center justify-center border border-line text-sm text-muted-foreground">
                    Pinterest image not connected yet
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
