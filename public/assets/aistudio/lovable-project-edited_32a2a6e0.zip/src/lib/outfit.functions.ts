import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type ClothingAnalysis = {
  type: string;
  primaryColor: string;
  secondaryColors: string[];
  pattern: string;
  style: string;
  fabric: string;
  aesthetic: string;
};

export type OutfitRecommendation = {
  top: number;
  bottom: number;
  score: number;
  style: string;
  colors: string;
  reason: string;
  occasion: string;
};

const DATA_URL_PATTERN = /^data:image\/(png|jpeg|webp);base64,/;
const MAX_DATA_URL_CHARS = 6_000_000;

const analyseInput = z.object({ images: z.array(z.string()).min(1).max(14) });

/** Analyse each clothing photo once; the browser caches results so photos are never re-sent. */
export const analyseClothing = createServerFn({ method: "POST" })
  .inputValidator((d) => analyseInput.parse(d))
  .handler(async ({ data }): Promise<{ items: ClothingAnalysis[] }> => {
    const { geminiJson, GeminiError } = await import("./gemini.server");
    const parts: Parameters<typeof geminiJson>[0] = [
      { text: `Analyse these ${data.images.length} clothing photos, in order. Return exactly one item per photo.` },
    ];
    for (const [i, url] of data.images.entries()) {
      const m = url.match(DATA_URL_PATTERN);
      if (!m) throw new Error("Only PNG, JPEG or WebP images can be analysed.");
      if (url.length > MAX_DATA_URL_CHARS) throw new Error("One of the images is too large to analyse.");
      parts.push({ text: `Photo ${i + 1}:` });
      parts.push({ inline_data: { mime_type: `image/${m[1]}`, data: url.slice(m[0].length) } });
    }
    const str = { type: "STRING" };
    try {
      const out = await geminiJson<{ items: ClothingAnalysis[] }>(
        parts,
        {
          type: "OBJECT",
          properties: {
            items: {
              type: "ARRAY",
              items: {
                type: "OBJECT",
                properties: {
                  type: str, primaryColor: str, secondaryColors: { type: "ARRAY", items: str },
                  pattern: str, style: str, fabric: str, aesthetic: str,
                },
                required: ["type", "primaryColor", "secondaryColors", "pattern", "style", "fabric", "aesthetic"],
              },
            },
          },
          required: ["items"],
        },
        "You are a fashion expert. For each clothing photo identify: type (shirt, T-shirt, polo, trousers, jeans, chinos, shorts...), primaryColor, secondaryColors, pattern/print (or 'solid'), style (casual, formal, smart casual, streetwear...), fabric appearance/texture ('unclear' if not identifiable), and overall aesthetic.",
      );
      if (out.items?.length !== data.images.length) throw new GeminiError("The AI couldn't analyse every photo. Please try again.");
      return out;
    } catch (e) {
      if (e instanceof GeminiError) throw new Error(e.message);
      throw e;
    }
  });

const itemSchema = z.object({
  type: z.string(), primaryColor: z.string(), secondaryColors: z.array(z.string()),
  pattern: z.string(), style: z.string(), fabric: z.string(), aesthetic: z.string(),
});
const recommendInput = z.object({
  tops: z.array(itemSchema).min(1).max(7),
  bottoms: z.array(itemSchema).min(1).max(7),
});

/** Compare analysed items (text only, no images) and pick the 3 best pairings. */
export const generateOutfits = createServerFn({ method: "POST" })
  .inputValidator((d) => recommendInput.parse(d))
  .handler(async ({ data }): Promise<{ recommendations: OutfitRecommendation[] }> => {
    const { geminiJson, GeminiError } = await import("./gemini.server");
    const str = { type: "STRING" };
    const int = { type: "INTEGER" };
    let out: { recommendations?: OutfitRecommendation[] };
    try {
      out = await geminiJson(
        [{ text: `Tops:\n${JSON.stringify(data.tops.map((t, i) => ({ index: i + 1, ...t })))}\n\nBottoms:\n${JSON.stringify(data.bottoms.map((b, i) => ({ index: i + 1, ...b })))}` }],
        {
          type: "OBJECT",
          properties: {
            recommendations: {
              type: "ARRAY",
              items: {
                type: "OBJECT",
                properties: { top: int, bottom: int, score: int, style: str, colors: str, reason: str, occasion: str },
                required: ["top", "bottom", "score", "style", "colors", "reason", "occasion"],
              },
            },
          },
          required: ["recommendations"],
        },
        "You are an expert stylist. Evaluate every top+bottom combination for colour harmony, pattern compatibility, style consistency and occasion suitability. Return the best 3 distinct combinations (fewer only if fewer exist), best first. For each: top and bottom (1-based indexes), score (integer 1-10 compatibility), style (outfit style name), colors (the colour combination, e.g. 'Navy + beige'), reason (one or two sentences why it works), occasion. Only use indexes that exist.",
      );
    } catch (e) {
      if (e instanceof GeminiError) throw new Error(e.message);
      throw e;
    }
    const recommendations = (out.recommendations ?? [])
      .filter((r) => r.top >= 1 && r.top <= data.tops.length && r.bottom >= 1 && r.bottom <= data.bottoms.length)
      .map((r) => ({ ...r, score: Math.min(10, Math.max(1, Math.round(r.score))) }))
      .slice(0, 3);
    if (!recommendations.length) throw new Error("The AI couldn't match these photos. Try clearer pictures.");
    return { recommendations };
  });
