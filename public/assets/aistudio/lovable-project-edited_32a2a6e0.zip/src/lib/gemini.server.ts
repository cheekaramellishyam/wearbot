// Server-only Google Gemini (free tier) client. Images are sent as Base64 inline data.
export const GEMINI_MODEL = "gemini-3.6-flash";

export class GeminiError extends Error {}

type Part = { text: string } | { inline_data: { mime_type: string; data: string } };

export async function geminiJson<T>(parts: Part[], schema: object, system: string): Promise<T> {
  const key = process.env["GEMINI_API_KEY"];
  if (!key) throw new GeminiError("The AI isn't set up yet. Add a Gemini API key to the project secrets.");

  let res: Response;
  try {
    res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
      {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts }],
          generationConfig: { responseMimeType: "application/json", responseSchema: schema },
        }),
      },
    );
  } catch (e) {
    console.error("Gemini network error", e);
    throw new GeminiError("Couldn't reach the AI service. Check your connection and try again.");
  }

  if (!res.ok) {
    const body = await res.text();
    console.error("Gemini error", res.status, body.slice(0, 500));
    if (res.status === 429) throw new GeminiError("The free AI quota is used up for now. Wait a minute (or until tomorrow) and try again.");
    if (res.status === 400 && /image|mime|inline/i.test(body)) throw new GeminiError("One of the photos couldn't be read. Try a different image.");
    if (res.status === 400 || res.status === 401 || res.status === 403) throw new GeminiError("The Gemini API key is missing or invalid. Check the project secret.");
    if (res.status >= 500) throw new GeminiError("The AI service is unavailable right now. Please try again shortly.");
    throw new GeminiError("The AI couldn't analyse these photos. Please try again.");
  }

  const json = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] }; finishReason?: string }[];
    promptFeedback?: { blockReason?: string };
  };
  if (json.promptFeedback?.blockReason) throw new GeminiError("The AI declined to analyse these photos. Try different images.");
  const text = json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new GeminiError("The AI returned an unreadable answer. Please try again.");
  }
}
