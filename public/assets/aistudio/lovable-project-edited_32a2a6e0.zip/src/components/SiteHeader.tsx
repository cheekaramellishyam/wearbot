import { Menu, Search, User } from "lucide-react";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background">
      <div className="relative mx-auto flex h-16 max-w-6xl items-center justify-between px-3 sm:px-4 md:h-20 md:px-8">
        <button type="button" aria-label="Open menu" className="p-1.5 sm:p-2 text-foreground hover:opacity-70">
          <Menu className="h-7 w-7" strokeWidth={1.5} />
        </button>
        <a href="/" className="absolute left-1/2 -translate-x-1/2" aria-label="WEARBOT home">
          <svg
            viewBox="0 0 175.45 28"
            className="h-4 w-auto text-foreground min-[400px]:h-5 md:h-7"
            aria-hidden="true"
            focusable="false"
          >
            <text x="0" y="27" textLength="175.45" lengthAdjust="spacingAndGlyphs" className="wearbot-wordmark">
              WEARBOT
            </text>
          </svg>
        </a>
        <div className="flex items-center gap-3 sm:gap-5 shrink-0">
          <button type="button" aria-label="Search" className="p-1.5 sm:p-2 text-foreground hover:opacity-70">
            <Search className="h-6 w-6" strokeWidth={1.5} />
          </button>
          <button type="button" aria-label="Profile" className="p-1.5 sm:p-2 text-foreground hover:opacity-70">
            <User className="h-6 w-6" strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </header>
  );
}
